import { useSession } from "next-auth/react";

export default function Profile() {
  const { data: session } = useSession();

  if (!session) {
    return <p>Loading...</p>;
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="bg-white p-6 rounded shadow-md w-80">
        <h2 className="mb-4 text-xl font-bold">Profile</h2>
        <div className="mb-4">
          <p className="text-sm font-medium">Email: {session.user?.email}</p>
        </div>
        {/* Adicione aqui outros campos que o usuário pode editar */}
      </div>
    </div>
  );
}
